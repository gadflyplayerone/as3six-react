export default function Privacy() {
  return (
    <main className="pt-20">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <header className="mb-6">
          <h1 className="text-3xl md:text-4xl font-semibold text-white">Privacy Policy</h1>
          <p className="mt-2 text-slate-300 text-sm">Effective date: 2025-01-01 (example)</p>
        </header>

        <article className="prose prose-invert prose-slate max-w-none">
          <p>
            This Privacy Policy describes how we collect, use, disclose, and safeguard information in connection
            with our website, products, and services.
          </p>

          <h2>Information We Collect</h2>
          <ul>
            <li><strong>Contact data</strong> (e.g., name, email, phone) when you reach out.</li>
            <li><strong>Usage data</strong> (device, pages viewed, approximate location) for analytics.</li>
            <li><strong>Communications</strong> you send us (email or forms).</li>
          </ul>

          <h2>How We Use Information</h2>
          <ul>
            <li>To provide, operate, and improve the site and services.</li>
            <li>To respond to inquiries and support requests.</li>
            <li>To analyze usage and enhance security.</li>
          </ul>

          <h2>Sharing</h2>
          <p>We do not sell personal data. We may share with service providers under contract, or as required by law.</p>

          <h2>Retention</h2>
          <p>We retain data only as long as necessary for the purposes above, or to satisfy legal obligations.</p>

          <h2>Your Choices</h2>
          <ul>
            <li>Opt out of non-essential analytics via your browser settings or cookie controls.</li>
            <li>Request access, correction, or deletion of your personal data by contacting us.</li>
          </ul>

          <h2>Contact</h2>
          <p>
            Questions? Email <a href="mailto:dolebob424@gmail.com">dolebob424@gmail.com</a>.
          </p>

          <h2>Updates</h2>
          <p>We may update this Policy. Material changes will be posted with a new “Effective date”.</p>
        </article>
      </div>
    </main>
  );
}
