/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        // now `font-sans` === Inter with sensible fallbacks
        sans: ["Inter", "ui-sans-serif", "system-ui", "Segoe UI", "Roboto", "Helvetica Neue", "Arial", "Noto Sans", "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"]
      },
      colors: {
        // choose any names you like
        theme: {
          light: "#9D9B14", // e.g., "#F8FAFC"
          dark:  "#291658"   // e.g., "#0F172A"
        }
    }
  },
  plugins: []
};
