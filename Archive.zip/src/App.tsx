// src/App.tsx
import Header from "./components/Header";
import Gallery from "./components/Gallery";
import Industries from "./components/Industries";
import Partnerships from "./components/Partnerships";
import Licensing from "./components/Licensing";
import Footer from "./components/Footer";




import pic1 from "assets/gallery/1.jpg";
import pic2 from "assets/gallery/2.jpg";
import pic3 from "assets/gallery/3.jpg";
import pic4 from "assets/gallery/4.jpg";
import pic5 from "assets/gallery/5.jpg";
import pic6 from "assets/gallery/6.jpg";
import pic7 from "assets/gallery/7.jpg";
import pic8 from "assets/gallery/8.jpg";

export default function App() {
  const images = [pic1, pic2, pic3, pic4, pic5, pic6, pic7, pic8];

  return (
    <div className="min-h-[200vh] bg-gradient-to-b from-slate-900 via-slate-800 to-slate-700">
      <Header />
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/cookies" element={<Cookies />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <main className="pt-16">

        {/* GALLERY */}
        <section id="about" className="scroll-mt-16">
          <Gallery
            title=""
            images={images}
            autoPlayMs={3000}
            headerOffsetPx={64}
          />
        </section>

        {/* PRICING */}
        <section
          id="industries"
          className="scroll-mt-16 mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16 text-slate-100"
        >
           <Industries />
        </section>

        {/* CONTACT (optional) */}
        <section
          id="partnerships"
          className="scroll-mt-16 mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16 text-slate-100"
        >
          <Partnerships />
        </section>

         <section
          id="licensing"
          className="scroll-mt-16 mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16 text-slate-100"
        >
          <Licensing />
        </section>
        <Footer
        companyName="AS3SIX"
        addressLines={["Stanton, MI", "United States"]}
        phone="+1 (202) 422-2951"
        email="dolebob424@gmail.com"
        social={{
          github: "https://github.com/as3ics",
          x: "https://x.com/as3six"
        }}
      />
      </main>
    </div>
  );
}
